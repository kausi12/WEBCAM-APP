
# Real-time Urban Micro-Climate Map using Public Webcams — Single Project

This repository contains both **backend (FastAPI)** and **frontend (React + Leaflet)** in one project folder.

## Prerequisites
- Python 3.10+
- Node.js 18+ and npm
- VS Code (recommended), with Python and ESLint extensions

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Run frontend (in a separate terminal)
```bash
cd frontend
npm install
npm run dev
```
Open the printed local URL (usually http://localhost:5173). Backend should be running on http://localhost:8000.

## Configure cameras
Edit `backend/cameras.json` and replace `url` with real webcam JPG endpoints. You can add more cameras with `lat`, `lng` coordinates.

## How it works
- The backend periodically downloads single JPEG frames from each webcam URL.
- A lightweight CV pipeline infers **sunny / overcast / wet** via brightness, contrast and saturation heuristics.
- Results are pushed to clients over **WebSockets**.
- The React map subscribes to `/ws` and updates marker icons live.

## Notes
- This is a starter project designed to be easy to run and extend. For production, consider adding Redis/PostgreSQL and auth.
