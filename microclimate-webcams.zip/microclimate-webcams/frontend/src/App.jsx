
import React, { useEffect, useRef, useState } from 'react'
import L from 'leaflet'

const icons = {
  sunny: L.divIcon({ html: '☀️', className: '', iconSize: [24,24] }),
  overcast: L.divIcon({ html: '☁️', className: '', iconSize: [24,24] }),
  wet: L.divIcon({ html: '💧', className: '', iconSize: [24,24] }),
  unknown: L.divIcon({ html: '❓', className: '', iconSize: [24,24] }),
}

export default function App() {
  const mapRef = useRef(null)
  const [markers, setMarkers] = useState({})
  const [cameras, setCameras] = useState([])

  useEffect(() => {
    const map = L.map(document.createElement('div'), { zoomControl: true })
    map.setView([22.9734, 78.6569], 5)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(map)
    mapRef.current = map
    document.getElementById('root').appendChild(map.getContainer())
    map.getContainer().classList.add('map')

    fetch('http://localhost:8000/api/cameras')
      .then(r => r.json())
      .then(data => {
        setCameras(data)
        const mk = {}
        data.forEach(cam => {
          const marker = L.marker([cam.lat, cam.lng], { icon: icons.unknown })
            .addTo(map)
            .bindPopup(`<b>${cam.name}</b><br/><span id="info-${cam.id}">Waiting...</span>`)
          mk[cam.id] = marker
        })
        setMarkers(mk)
      })

    // WebSocket for live updates
    const ws = new WebSocket('ws://localhost:8000/ws')
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data)
        const marker = markers[msg.camera_id]
        if (marker) {
          marker.setIcon(icons[msg.condition] || icons.unknown)
          const el = document.getElementById(`info-${msg.camera_id}`)
          if (el) {
            el.innerHTML = `Condition: <b>${msg.condition}</b><br/>Brightness: ${msg.brightness}<br/>Contrast: ${msg.contrast}`
          }
        }
      } catch (e) { /* ignore */ }
    }
    ws.onerror = () => console.log('WebSocket error')

    return () => {
      ws.close()
      map.remove()
    }
  }, [])

  return (
    <div className="legend">
      <div><strong>Legend</strong></div>
      <div>☀️ Sunny</div>
      <div>☁️ Overcast</div>
      <div>💧 Wet</div>
      <div>❓ Unknown</div>
    </div>
  )
}
