
# Backend (FastAPI) — Real-time Urban Micro-Climate Map

## Quick start
1) Create venv & install deps
```bash
cd backend
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
2) Run the API
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Endpoints
- `GET /api/health` — health check
- `GET /api/cameras` — list configured cameras (from `cameras.json`)
- `WS /ws` — live stream of inferred micro-climate updates

## Configure cameras
Edit `cameras.json`. Each entry needs: `id`, `name`, `lat`, `lng`, `url` (image or mjpeg/jpg endpoint).

## Notes
- CV in `cv.py` is intentionally simple and fast: it estimates sun/overcast and wetness from brightness/contrast and color ratios.
- If a webcam URL is unreachable, the system skips it and keeps trying periodically.
