
import numpy as np
import cv2

def analyze_frame(frame: np.ndarray):
    """Return simple micro-climate inference from a BGR image.
    Heuristics:
      - brightness: mean of V in HSV
      - contrast: stddev of grayscale
      - wetness proxy: higher saturation with low brightness could hint 'wet' surfaces (very rough)
    """
    if frame is None or frame.size == 0:
        return {"condition": "unknown", "brightness": 0.0, "contrast": 0.0}

    # Resize small for speed
    h, w = frame.shape[:2]
    scale = 480 / max(h, w)
    if scale < 1.0:
        frame = cv2.resize(frame, (int(w*scale), int(h*scale)))

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    v = hsv[:, :, 2]
    s = hsv[:, :, 1]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    brightness = float(np.mean(v)) / 255.0
    contrast = float(np.std(gray)) / 255.0
    sat = float(np.mean(s)) / 255.0

    # Very naive rules
    condition = "unknown"
    if brightness > 0.6 and contrast > 0.18:
        condition = "sunny"
    elif brightness < 0.35 and contrast < 0.12:
        condition = "overcast"
    # wetness proxy (dark but saturated colors pop due to reflections)
    if brightness < 0.45 and sat > 0.35 and contrast > 0.10:
        condition = "wet"

    return {
        "condition": condition,
        "brightness": round(brightness, 3),
        "contrast": round(contrast, 3),
    }
