
from pydantic import BaseModel, Field
from typing import Optional, Literal

class Camera(BaseModel):
    id: str
    name: str
    lat: float
    lng: float
    url: str

class MicroClimate(BaseModel):
    camera_id: str
    condition: Literal["sunny", "overcast", "wet", "unknown"]
    brightness: float = Field(ge=0)
    contrast: float = Field(ge=0)
    timestamp: float  # epoch seconds
