
import asyncio
import json
import os
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from .models import Camera, MicroClimate
from .ingest import Ingestor

ROOT = os.path.dirname(os.path.dirname(__file__))
CAMS_PATH = os.path.join(ROOT, "cameras.json")

app = FastAPI(title="Micro-Climate from Public Webcams")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load cameras
with open(CAMS_PATH, "r", encoding="utf-8") as f:
    CAMERA_LIST = [Camera(**c).model_dump() for c in json.load(f)]

ingestor = Ingestor(CAMERA_LIST, interval_sec=20)

@app.on_event("startup")
async def on_startup():
    ingestor.start()

@app.on_event("shutdown")
async def on_shutdown():
    ingestor.stop()

@app.get("/api/health")
async def health():
    return {"status": "ok"}

@app.get("/api/cameras")
async def get_cameras():
    return CAMERA_LIST

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    q = ingestor.subscribe()
    try:
        while True:
            payload = await q.get()
            await ws.send_json(payload)
    except WebSocketDisconnect:
        pass
    finally:
        ingestor.unsubscribe(q)
