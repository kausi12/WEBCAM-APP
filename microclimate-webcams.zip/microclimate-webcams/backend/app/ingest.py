
import asyncio
import time
from typing import List, Dict, Any
import aiohttp
import cv2
import numpy as np

from .cv import analyze_frame

class Ingestor:
    def __init__(self, cameras: List[Dict[str, Any]], interval_sec: int = 15):
        self.cameras = cameras
        self.interval = interval_sec
        self.subscribers: List[asyncio.Queue] = []
        self._task: asyncio.Task | None = None

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue()
        self.subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue):
        if q in self.subscribers:
            self.subscribers.remove(q)

    async def _broadcast(self, msg: Dict[str, Any]):
        for q in list(self.subscribers):
            try:
                await q.put(msg)
            except asyncio.CancelledError:
                pass
            except Exception:
                # drop problematic subscriber
                try:
                    self.subscribers.remove(q)
                except ValueError:
                    pass

    async def fetch_image(self, session: aiohttp.ClientSession, url: str) -> np.ndarray | None:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    return None
                data = await resp.read()
                arr = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                return frame
        except Exception:
            return None

    async def run(self):
        while True:
            try:
                async with aiohttp.ClientSession() as session:
                    for cam in self.cameras:
                        frame = await self.fetch_image(session, cam["url"])
                        metrics = analyze_frame(frame)
                        payload = {
                            "camera_id": cam["id"],
                            "condition": metrics["condition"],
                            "brightness": metrics["brightness"],
                            "contrast": metrics["contrast"],
                            "timestamp": time.time(),
                        }
                        await self._broadcast(payload)
                await asyncio.sleep(self.interval)
            except asyncio.CancelledError:
                break
            except Exception:
                # backoff a bit on errors
                await asyncio.sleep(self.interval)

    def start(self):
        if not self._task or self._task.done():
            self._task = asyncio.create_task(self.run())

    def stop(self):
        if self._task:
            self._task.cancel()
